# À compléter

Scripts cités dans le manuscrit :

- `CM_Parameter_Search.py` : modèle à coquille unique et balayage de la conductivité cytoplasmique ;
- `CO2_Limitation_Cavite.py` : bilan du carbone et de l'oxygène, carte d'appauvrissement dans la cavité ;
- ajustements des cinétiques d'installation et de relaxation de l'inversion.
